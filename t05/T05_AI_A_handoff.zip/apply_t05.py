#!/usr/bin/env python3
"""Apply T05 safety/error messages to the EXACT T03 base commit script.js.
Run from extracted repository: python path/to/apply_t05.py t03/script.js
"""
from pathlib import Path
import sys
p=Path(sys.argv[1] if len(sys.argv)>1 else 't03/script.js')
s=p.read_text(encoding='utf-8')
changes=[]
def replace(old,new,label):
 global s
 n=s.count(old)
 if n!=1: raise SystemExit(f'ERROR: {label}: expected 1 match, found {n}; original left unchanged')
 s=s.replace(old,new,1);changes.append(label)
replace("const validTemplate = (t) =>",'''function bundleError(data) {
  if (!data || typeof data !== 'object' || Array.isArray(data)) return 'JSON 최상위 구조가 객체가 아닙니다';
  if (!own(data,'version')) return '필수 필드 version이 없습니다';
  if (data.version !== 1) return '지원하지 않는 JSON 버전입니다 (version: 1 필요)';
  if (!own(data,'editor')) return '필수 필드 editor가 없습니다';
  if (!data.editor || typeof data.editor !== 'object' || Array.isArray(data.editor)) return 'editor는 객체여야 합니다';
  for (const key of ['ratio','text','fontSize','color','x','y','background']) {
    if (!own(data.editor,key)) return `필수 필드 editor.${key}가 없습니다`;
  }
  if (!validEditor(data.editor)) return 'editor의 값 또는 이미지 형식이 올바르지 않습니다';
  if (!own(data,'templates')) return '필수 필드 templates가 없습니다';
  if (!Array.isArray(data.templates)) return 'templates는 배열이어야 합니다';
  if (data.templates.length > 24) return '템플릿은 24개를 초과할 수 없습니다';
  for (let i=0;i<data.templates.length;i++) {
    const t=data.templates[i];
    if (!t || typeof t!=='object' || Array.isArray(t)) return `templates[${i}]는 객체여야 합니다`;
    for (const key of ['id','name','editor']) if (!own(t,key)) return `필수 필드 templates[${i}].${key}가 없습니다`;
    if (!t.editor || typeof t.editor!=='object' || Array.isArray(t.editor)) return `templates[${i}].editor가 올바르지 않습니다`;
    for (const key of ['ratio','text','fontSize','color','x','y','background']) {
      if (!own(t.editor,key)) return `필수 필드 templates[${i}].editor.${key}가 없습니다`;
    }
    if (!validTemplate(t)) return `templates[${i}]의 값 또는 이미지 형식이 올바르지 않습니다`;
  }
  if (new Set(data.templates.map(t=>t.id)).size !== data.templates.length) return '템플릿 ID가 중복되었습니다';
  return null;
}
const validTemplate = (t) =>''', 'describe bundle invalidity')
replace("if(!validBundle(parsed))throw new Error('필수 항목 누락 또는 지원하지 않는 구조');", "const invalid=bundleError(parsed);if(invalid)throw new Error(invalid);", 'specific JSON errors')
replace("const parsed=JSON.parse(await file.text());",'''let parsed;
    try { parsed=JSON.parse(await file.text()); }
    catch(e) { if(e instanceof SyntaxError) throw new Error('JSON 문법이 올바르지 않습니다'); throw e; }''','JSON syntax errors')
replace("if(parsed.editor.background.type==='upload')restoreImg=await loadImage(parsed.editor.background.data);\n    for(const t of parsed.templates){if(t.editor.background.type==='upload')await loadImage(t.editor.background.data);}",'''if(parsed.editor.background.type==='upload') {
      try {restoreImg=await loadImage(parsed.editor.background.data);}
      catch(e) {throw new Error('현재 편집 이미지가 손상되어 열 수 없습니다');}
    }
    for(let i=0;i<parsed.templates.length;i++) {
      const t=parsed.templates[i];
      if(t.editor.background.type==='upload') {
        try {await loadImage(t.editor.background.data);}
        catch(e) {throw new Error(`템플릿 ${i+1} (${t.name})의 이미지가 손상되어 열 수 없습니다`);}
      }
    }''','locate damaged JSON image')
replace("if(!kind)throw new Error('파일 내용이 PNG 또는 JPEG 형식이 아닙니다.');", "if(!kind)throw new Error('지원하지 않는 이미지 형식입니다. PNG 또는 JPEG 파일을 선택하세요.');",'unsupported image message')
replace("const img=await loadImage(source);",'''let img;
  try {img=await loadImage(source);}
  catch(e){throw new Error(`파일은 ${kind.toUpperCase()} 형식이지만 이미지가 손상되어 열 수 없습니다.`); }''','corrupt image message')
replace("if (!validBundle(data)) throw new Error('Invalid saved data');", "if (!validBundle(data)) throw new Error('Invalid saved data');",'preserve startup bundle guard')
# Avoid resetting saved records on corrupted editor image in startup.
replace("loadImage(editor.background.data).then(img=>{uploadedImage=img;draw();}).catch(()=>{editor=freshEditor();uploadedImage=null;syncControls();draw();report('저장된 배경 이미지가 손상되어 안전한 예제 화면으로 복구했습니다.',true);});", "loadImage(editor.background.data).then(img=>{uploadedImage=img;draw();}).catch(()=>{uploadedImage=null;draw();report('저장된 배경 이미지를 표시하지 못했습니다. 기록과 템플릿은 보존했으니 JSON 백업 후 이미지 교체를 권장합니다.',true);});",'protect stored editor on startup')
p.write_text(s,encoding='utf-8')
print('PATCH APPLIED: '+', '.join(changes))
