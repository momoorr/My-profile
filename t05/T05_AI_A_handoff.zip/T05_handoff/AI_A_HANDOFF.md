# T05 AI A → AI B 인수인계 (실제 수행 범위)

## 작업 기준
- AI A: ChatGPT GPT-6 / AI B 예정: Gemini (사용자가 지정)
- 시작 소스 SHA: `ebd702bcba8169c305d5a15e5201076e5ca02b86`
- 작업 제한: 최대 20분 / 사용자 요청 최대 5회. 실제 시작 관찰 시각: 2026-10-22 16:16 KST (시스템에 제공됨); 종료 시각은 직접 기록 필요.
- 원본 GitHub `t03/script.js` 열람 완료. 원격 권한 pull=true, push=false.
- C01~C10: ZIP의 `01_FIXED_CHECKS.md` 원문 보존. 비교 조건 변경 0건.

## 현재 상태
- 완료: 원본 코드 확인, 고정 10검사 원문 확인, 오류 안내 개선 적용용 스크립트 `apply_t05.py` 작성, Python 문법 검사.
- 미완료: `t03/script.js` 실제 원본 파일에 패치 적용, 페이지 구동, 10개 고정 UI 검사, 새 commit 생성, 배포, 브라우저 검증.
- 중요: GitHub API 도구로 원본 코드를 읽었지만 실행 컨테이너에서 `git clone`은 DNS 오류(`Could not resolve host: github.com`)로 실패. 이 자료는 **수정 스크립트**이지 수정된 소스 commit이 아님.

## 변경 예정 부분
- 잘못된 JSON 문법을 명확히 표시.
- version/editor/templates 필수 필드 누락을 필드명으로 구분.
- JSON 내부 손상된 현재 이미지/템플릿 이미지의 위치를 표시.
- PNG/JPEG 이외 파일과 실제 디코딩 불가 파일의 오류 안내를 구분.
- 시작 시 저장 이미지 로드 실패해도 기존 editor/templates 객체를 재설정하지 않도록 개선.
- 기존 PNG 저장, 문구 편집, 템플릿 관리 로직은 수정 대상이 아님.

## 재현·적용
```bash
# 지정 SHA의 저장소를 수동 다운로드/clone하여 해당 디렉터리에서 실행
python3 apply_t05.py t03/script.js
node --check t03/script.js
python3 -m http.server 8000
# 브라우저 http://localhost:8000/t03/ 접속해 원문 C01~C10 실행
```
`apply_t05.py`는 지정 문자열 하나라도 일치하지 않으면 쓰기 전에 종료해 원본 파일을 유지함. 패치는 원본 상태에서 딱 한 번 실행.

## 검사 상태
| ID | AI A 종료 | 실제 증거 |
|---|---|---|
| C01 | 미확인 | 브라우저 테스트 미실행 |
| C02 | 미확인 | 브라우저 테스트 미실행 |
| C03 | 미확인 | 브라우저 테스트 미실행 |
| C04 | 미확인 | 브라우저 테스트 미실행 |
| C05 | 미확인 | 브라우저 테스트 미실행 |
| C06 | 미확인 | 브라우저 테스트 미실행 |
| C07 | 미확인 | 브라우저 테스트 미실행 |
| C08 | 미확인 | 브라우저 테스트 미실행 |
| C09 | 미확인 | 브라우저 테스트 미실행 |
| C10 | 미확인 | 브라우저 테스트 미실행 |

- 점검 완료: `python -m py_compile apply_t05.py` (PASS, 스크립트 문법만)
- 실패: `git clone https://github.com/momoorr/My-profile.git` (컨테이너 DNS 차단)

## 다음 행동
1. 실제 T03 원본 `t03/script.js`를 확보해 `apply_t05.py` 실행 후 `node --check` 수행하고 변경 diff 저장.
2. 동일 원문 C01~C10을 브라우저에서 수동/자동 실행, 각 PASS/FAIL과 증거·시각 기록.
3. 원격 쓰기 권한이 있는 로컬 PC에서 commit 작성, 40자 SHA 기록 후 A→B 전달.

## 주의
- 템플릿 데이터를 JSON으로 교체하기 전에 모두 검증하도록 유지.
- 원래의 고정 검사 파일을 편집하지 말 것.
- 이 문서의 미확인 항목을 PASS로 변경하지 말 것.
